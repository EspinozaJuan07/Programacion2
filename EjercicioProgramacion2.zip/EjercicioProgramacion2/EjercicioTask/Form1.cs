﻿namespace EjercicioTask
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btncalcular_Click(object sender, EventArgs e)
        {
            txtresultado.Clear();

            if (int.TryParse(maskedTextBox1.Text, out int number))
            {
                // Calcula el factorial en paralelo
                long factorial = await Task.Run(() => CalcularFactorial(number));
                txtresultado.Text = factorial.ToString();
            }
            else
            {
                MessageBox.Show("Ingrese un número entero válido.");
            }
        }

        private long CalcularFactorial(int number)
        {
            long result = 1;
            for (int i = 1; i <= number; i++)
            {
                result = result * i;
            }
            return result;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtresultado.Enabled = false;
        }
    }
}
